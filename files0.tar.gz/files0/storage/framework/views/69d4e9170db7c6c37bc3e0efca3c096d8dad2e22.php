<?php $__env->startSection('content'); ?>
<section class="hero-wrap hero-wrap-2" style="background-image: url(<?php echo e(asset('images/pix_2.jpg')); ?>);">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text align-items-end justify-content-center">
      <div class="col-md-9 ftco-animate pb-5 text-center">
       <p class="breadcrumbs"><span class="mr-2"><i>Write Like A </i><b>Ninja</b></span> </p>
       <h1 class="mb-0 bread">Welcome to our website</h1>
     </div>
   </div>
 </div>
</section>
<section class="ftco-section bg-light">
  <div class="container">
    <?php if(Session::has('success')): ?>
      <div class="alert alert-success" style="margin: -84px 0 48px 0;">
        <?php echo e(Session::get('success')); ?>

      </div>
    <?php endif; ?>
    <?php if($post->image): ?>
    
      <div style="background-image: url('<?php echo e($post['image']->url()); ?>'); min-height: 500px; color:white; text-align: center; background-attachment: fixed;">
        <h1 style="padding-top: 100px; text-shadow: 1px 2px #000">
    <?php else: ?>
      <h1>
    <?php endif; ?>
      <?php echo e($post->title); ?> 
      <?php $__env->startComponent('components.badge', ['type', 'show' => (new Carbon\Carbon())->diffInDays($post->created_at) < 1]); ?>
        New Post
      <?php echo $__env->renderComponent(); ?>
      <i></i>
    <?php if($post->image): ?>
        </h1>
      </div>
    <?php else: ?>
      </h1>
    <?php endif; ?>
    <br>
    
    </h1>
  
    <br><br>
    <p><?php echo e($post->content); ?></p>
    <p class="text-muted"> <?php $__env->startComponent('components.tags', ['tags' => $post['tags']]); ?>  <?php echo $__env->renderComponent(); ?> </p>
    <div style="text-align: right;">
      <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-sm btn-dark"><i class="fa fa-pencil bg-dark"></i> Edit Post</a>
    </div>
    <p class="text-muted"> <?php $__env->startComponent('components.updated', ['time' => true, 'date' => $post->created_at, 'name' => $post['user']->name, 'userId' => $post['user']->id]); ?> <?php echo $__env->renderComponent(); ?></p>
    <p class="text-muted"> <?php $__env->startComponent('components.updated', ['time' => $post->updated_at, 'date' => $post->updated_at]); ?> Updated <?php echo $__env->renderComponent(); ?></p>

    <div class="container mt-5">
      <div class="row d-flex ">
        <div class="col-md-8">
            <?php $__env->startComponent('components.comment-form', ['route' => route('post.comment.store', $post->id)]); ?> <?php echo $__env->renderComponent(); ?>
        </div>
      </div>
    </div>
  </div>
  <div class="container mt-5">
    <div class="row d-flex ">
      <div class="col-md-8">
        <div class="headings d-flex justify-content-between align-items-center mb-3">
          <h5>Latest Comments</h5>
        </div>
        
        <?php $__env->startComponent('components.comment-list', ['comments' => $post['comments']]); ?> <?php echo $__env->renderComponent(); ?>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sam/projects/blog-project/resources/views/posts/show.blade.php ENDPATH**/ ?>