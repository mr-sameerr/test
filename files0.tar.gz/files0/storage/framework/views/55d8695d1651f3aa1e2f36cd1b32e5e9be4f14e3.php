<?php $__env->startSection('content'); ?>
<section class="hero-wrap hero-wrap-2" style="background-image: url(<?php echo e(asset('images/pix_2.jpg')); ?>);">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text align-items-end justify-content-center">
      <div class="col-md-9 ftco-animate pb-5 text-center">
       <p class="breadcrumbs"><span class="mr-2"><i>Write Like A </i><b>Ninja</b></span> </p>
       <h1 class="mb-0 bread">Welcome to our website</h1>
     </div>
   </div>
 </div>
</section>
<section class="ftco-section bg-light">
<div class="container">
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success" style="margin: -84px 0 48px 0;">
            <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(Session::has('fail')): ?>
        <div class="alert alert-danger" style="margin: -84px 0 48px 0;">
            <?php echo e(Session::get('fail')); ?>

        </div>
    <?php endif; ?>
    <div class="row d-flex">
      

   <div class="col-lg-4 ftco-animate">
    <div class="blog-entry">
      <a href="blog-single.html" class="block-20" style="background-image: url('images/image_2.jpg');">
      </a>
      <div class="text d-block">
       <div class="meta">
        <p>
         <a href="#"><span class="fa fa-calendar mr-2"></span>Sept. 17, 2020</a>
         <a href="#"><span class="fa fa-user mr-2"></span>Admin</a>
         <a href="#" class="meta-chat"><span class="fa fa-comment mr-2"></span> 3</a>
       </p>
     </div>
     <h3 class="heading"><a href="#">I'm not creative, Should I take this course?</a></h3>
     <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia...</p>
     <p><a href="blog.html" class="btn btn-secondary py-2 px-3">Read more</a></p>
   </div>
 </div>
</div>
<div class="col-lg-4 ftco-animate">
  <div class="blog-entry">
    <a href="blog-single.html" class="block-20" style="background-image: url('images/image_3.jpg');">
    </a>
    <div class="text d-block">
     <div class="meta">
      <p>
       <a href="#"><span class="fa fa-calendar mr-2"></span>Sept. 17, 2020</a>
       <a href="#"><span class="fa fa-user mr-2"></span>Admin</a>
       <a href="#" class="meta-chat"><span class="fa fa-comment mr-2"></span> 3</a>
     </p>
   </div>
   <h3 class="heading"><a href="#">I'm not creative, Should I take this course?</a></h3>
   <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia...</p>
   <p><a href="blog.html" class="btn btn-secondary py-2 px-3">Read more</a></p>
 </div>
</div>
</div>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<div class="col-lg-4 ftco-animate">
    <div class="blog-entry">
        <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="block-20" style="background-image: url('images/image_4.jpg');"></a>
        <div class="text d-block">
            <div class="meta">
                <p>
                  <a href="#"><span class="fa fa-calendar mr-2"></span> <?php echo e(date('Y, m d', strtotime($post->created_at))); ?></a>
                  <a href="<?php echo e(route('user.show', $post['user']->id)); ?>"><span class="fa fa-user mr-2"></span><?php echo e($post['user']->name); ?></a>
                  <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="meta-chat"><span class="fa fa-comment mr-2"></span> <?php echo e($post->comments_count); ?></a>                    
                </p>
                <p>
                   <a href="<?php echo e(route('posts.edit', $post->id)); ?>" title="Edit Your Profile" class="meta-chat"><span class="fa fa-edit mr-2"></span></a> 
                </p>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $post)): ?>
                <p>
                  <form id="delete-form" action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm"><i class="fa fa-trash"></i></button>
                  </form>
                </p>
                <?php endif; ?>
            </div>
            <h3 class="heading"><a href="<?php echo e(route('posts.show', $post->id)); ?>"><?php echo e($post->title); ?></a></h3>
            <p><?php echo str_limit(($post->content), 300); ?></p>
            <p class="text-muted">
              <?php $__env->startComponent('components.tags', ['tags' => $post['tags']]); ?> <?php echo $__env->renderComponent(); ?>
            </p>
            <p><a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-secondary py-2 px-3">Read more</a></p>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<div class="col-lg-4 ftco-animate">
  <div class="blog-entry">
    <a href="blog-single.html" class="block-20" style="background-image: url('images/image_6.jpg');">
    </a>
    <div class="text d-block">
     <div class="meta">
      <p>
       <a href="#"><span class="fa fa-calendar mr-2"></span>Sept. 17, 2020</a>
       <a href="#"><span class="fa fa-user mr-2"></span>Admin</a>
       <a href="#" class="meta-chat"><span class="fa fa-comment mr-2"></span> 3</a>
     </p>
   </div>
   <h3 class="heading"><a href="#">I'm not creative, Should I take this course?</a></h3>
   <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia...</p>
   <p><a href="blog.html" class="btn btn-secondary py-2 px-3">Read more</a></p>
 </div>
</div>
</div>
</div>
</section>
<!-- <div class="row mt-5">
  <div class="col text-center">
    <div class="block-27">
      <ul>
        <li><a href="#">&lt;</a></li>
        <li class="active"><span>1</span></li>
        <li><a href="#">2</a></li>
        <li><a href="#">3</a></li>
        <li><a href="#">4</a></li>
        <li><a href="#">5</a></li>
        <li><a href="#">&gt;</a></li>
      </ul>
    </div>
  </div>
</div>
</div> -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sam/projects/blog-project/resources/views/posts/index.blade.php ENDPATH**/ ?>