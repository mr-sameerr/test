<?php $__env->startComponent('mail::message'); ?>
# Comment was posted on post you're watching.



<?php echo e(ucwords($comment['commentable']->name)); ?> posted comment on your blog post.

<?php $__env->startComponent('mail::button', ['url' => route('posts.show', $comment->commentable->id)]); ?>
View Post here
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => route('user.show', $comment->commentable->user->id)]); ?>
Visit <?php echo e($comment['commentable']->name); ?> profile
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::panel'); ?>
	<?php echo e($comment->description); ?>

<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /home/sam/projects/blog-project/resources/views/emails/posts/comment-notifier-other.blade.php ENDPATH**/ ?>