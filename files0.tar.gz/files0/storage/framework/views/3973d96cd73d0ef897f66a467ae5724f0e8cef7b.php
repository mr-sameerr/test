<?php if(!(isset($show)) || $show): ?>
	<span class="badge badge-<?php echo e($type ?? 'success'); ?>" style="font-size: medium;">
		<?php echo e($slot); ?>

	</span>
<?php endif; ?><?php /**PATH /home/sam/projects/blog-project/resources/views/components/badge.blade.php ENDPATH**/ ?>