<?php echo e($slot); ?>

<?php /**PATH /home/sam/projects/blog-project/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>