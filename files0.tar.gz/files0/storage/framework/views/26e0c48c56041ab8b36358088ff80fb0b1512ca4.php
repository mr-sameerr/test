<?php if(isset($time)): ?>
	<span class="text-muted">
		<?php echo e(empty(trim($slot)) ? 'Added' : $slot); ?> <?php echo e($date->diffForHumans()); ?>

		<?php if(isset($name)): ?>
			<?php if(isset($userId)): ?>
				<a href="<?php echo e(route('user.show', $userId)); ?>"><?php echo e($name); ?></a>
			<?php else: ?>
				<?php echo e($name); ?>

			<?php endif; ?>
		<?php endif; ?>
	</span>
<?php endif; ?><?php /**PATH /home/sam/projects/blog-project/resources/views/components/updated.blade.php ENDPATH**/ ?>