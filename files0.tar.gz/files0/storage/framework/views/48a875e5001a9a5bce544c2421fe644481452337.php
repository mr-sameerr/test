<?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<div class="card p-3 mt-2">
		<div class="d-flex justify-content-between align-items-center">
		<div class="user d-flex flex-row align-items-center"> 
			<img src="https://i.imgur.com/hczKIze.jpg" width="30" class="user-img rounded-circle mr-2">
			<span><small class="font-weight-bold text-primary"><?php echo e(ucwords($comment['commentedByUser']->name)); ?></small>
					<p><small class="font-weight-bold"><?php echo e($comment->description); ?></small></p>
				</span>
			</div>
			<small><?php echo e($comment->created_at->diffForHumans()); ?></small>
		</div>
		<div class="action d-flex justify-content-between mt-2 align-items-center">
			<div class="reply px-4">
				<small>Remove</small><span class="dots"></span>
				<small>Reply</small> <span class="dots"></span>
			</div>
		</div>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<p>No Comments Here..!!</p>
<?php endif; ?><?php /**PATH /home/sam/projects/blog-project/resources/views/components/comment-list.blade.php ENDPATH**/ ?>